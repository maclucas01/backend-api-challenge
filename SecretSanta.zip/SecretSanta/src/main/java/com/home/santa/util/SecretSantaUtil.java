package com.home.santa.util;


import org.apache.commons.lang3.ArrayUtils;

import java.util.Random;

public class SecretSantaUtil {

    public static Integer pickRandomId(Integer[] array) {
        int rnd = new Random().nextInt(array.length);
        return array[rnd];
    }

    public static Integer[] removeFromArray(Integer[] array, int value) {
        return ArrayUtils.remove(array, ArrayUtils.indexOf(array, value));
    }

}
