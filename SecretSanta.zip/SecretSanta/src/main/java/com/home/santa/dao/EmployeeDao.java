package com.home.santa.dao;

import com.home.santa.entity.Employee;

import java.util.List;

public interface EmployeeDao {

    List<Employee> findAll();

    Employee findById(int id);

    void removeById(int id);

    void add(Employee employee);

    List<Integer> getAllIds();
}
