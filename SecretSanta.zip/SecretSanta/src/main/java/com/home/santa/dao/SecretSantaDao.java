package com.home.santa.dao;

import com.home.santa.entity.SecretSanta;

import java.util.List;

public interface SecretSantaDao {

    List<SecretSanta> findAll();

    List<SecretSanta> findByYear(int year);

    void addAll(List<SecretSanta> secretSantas);

    List<SecretSanta> findByYearAndGiverId(List<Integer> years, Integer giverId);
}
