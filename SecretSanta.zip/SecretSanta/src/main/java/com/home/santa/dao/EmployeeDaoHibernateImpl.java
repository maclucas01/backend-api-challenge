package com.home.santa.dao;

import com.home.santa.entity.Employee;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;

@Repository
public class EmployeeDaoHibernateImpl implements EmployeeDao {

    private EntityManager entityManager;

    @Autowired
    public EmployeeDaoHibernateImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public List<Employee> findAll() {
        Session cs = entityManager.unwrap(Session.class);
        Query<Employee> theQuery = cs.createQuery("from Employee", Employee.class);
        List<Employee> employees = theQuery.getResultList();
        return employees;
    }

    @Override
    public Employee findById(int id) {
        Session cs = entityManager.unwrap(Session.class);
        Employee employee = cs.get(Employee.class, id);
        return employee;
    }

    @Override
    public List<Integer> getAllIds() {
        Session cs = entityManager.unwrap(Session.class);
        return cs.createQuery("SELECT e.id FROM Employee e").list();
    }

    @Override
    public void removeById(int id) {
        Session cs = entityManager.unwrap(Session.class);
        Query theQuery = cs.createQuery("delete  from Employee where id=:employeeId");
        theQuery.setParameter("employeeId", id);
        theQuery.executeUpdate();
    }

    @Override
    public void add(Employee employee) {
        Session cs = entityManager.unwrap(Session.class);
        cs.saveOrUpdate(employee);
    }
}
