package com.home.santa.entity;

import javax.persistence.*;

@Entity
@Table(name = "secret_santa")
public class SecretSanta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "giver_id")
    private int giverId;

    @Column(name = "receiver_id")
    private int receiverId;

    @Column(name = "year")
    private int year;

    public SecretSanta(int giverId, int receiverId, int year) {
        this.giverId = giverId;
        this.receiverId = receiverId;
        this.year = year;
    }

    public SecretSanta() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGiverId() {
        return giverId;
    }

    public void setGiverId(int giverId) {
        this.giverId = giverId;
    }

    public int getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(int receiverId) {
        this.receiverId = receiverId;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
