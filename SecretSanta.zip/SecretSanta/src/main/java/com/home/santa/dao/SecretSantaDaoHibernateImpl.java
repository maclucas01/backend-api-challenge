package com.home.santa.dao;

import com.home.santa.entity.SecretSanta;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.List;

@Repository
public class SecretSantaDaoHibernateImpl implements SecretSantaDao {

    private EntityManager entityManager;

    @Autowired
    public SecretSantaDaoHibernateImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public List<SecretSanta> findAll() {
        Session cs = entityManager.unwrap(Session.class);
        Query<SecretSanta> theQuery = cs.createQuery("from SecretSanta", SecretSanta.class);
        List<SecretSanta> secretSantas = theQuery.getResultList();
        return secretSantas;
    }

    @Override
    public List<SecretSanta> findByYear(int year) {
        Session cs = entityManager.unwrap(Session.class);
        Query<SecretSanta> theQuery = cs.createQuery("from SecretSanta where year=:year", SecretSanta.class);
        theQuery.setParameter("year", year);
        List<SecretSanta> secretSantas = theQuery.getResultList();
        return secretSantas;
    }

    @Override
    public List<SecretSanta> findByYearAndGiverId(List<Integer> years, Integer giverId) {
        Session cs = entityManager.unwrap(Session.class);
        Query<SecretSanta> theQuery = cs.createQuery("from SecretSanta where year IN :years and giverId=:giverId", SecretSanta.class);
        theQuery.setParameterList("years", years);
        theQuery.setParameter("giverId", giverId);
        List<SecretSanta> secretSantas = theQuery.getResultList();
        return secretSantas;
    }

    @Override
    public void addAll(List<SecretSanta> secretSantas) {
        for (SecretSanta secretSanta : secretSantas) {
            entityManager.persist(secretSanta);
        }
    }
}
