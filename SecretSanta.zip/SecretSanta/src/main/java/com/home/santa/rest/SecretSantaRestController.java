package com.home.santa.rest;

import com.home.santa.entity.SecretSanta;
import com.home.santa.service.EmployeeService;
import com.home.santa.service.SecretSantaService;
import com.home.santa.util.SecretSantaUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api")
public class SecretSantaRestController {

    private SecretSantaService secretSantaService;
    private EmployeeService employeeService;

    @Autowired
    public void setEmployeeDao(SecretSantaService secretSantaService) {
        this.secretSantaService = secretSantaService;
    }

    @Autowired
    public void setEmployeeService(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/secretSanta")
    public List<SecretSanta> findAll() {
        return secretSantaService.findAll();
    }

    @GetMapping("/secretSanta/{year}")
    public List<SecretSanta> findByYear(@PathVariable int year) {
        return secretSantaService.findByYear(year);
    }

    @PutMapping("/pickSecretSanta/{year}")
    public void pickSecretSanta(@PathVariable int year) {
        List<SecretSanta> secretSantas = new ArrayList<>();

        //get all employee ids - should work much faster than getting all Employee objects
        List<Integer> ids = employeeService.getAllIds();

        //create an array of ids, which can be used as a set of receivers
        Integer[] receivers = ids.toArray(new Integer[0]);

        //set tries counter - prevent infinite loop
        int triesCounter = ids.size();

        for (Integer i : ids) {
            Integer randomId = SecretSantaUtil.pickRandomId(receivers);
            SecretSanta secretSanta = new SecretSanta();
            secretSanta.setGiverId(i);
            secretSanta.setYear(year);
            while (triesCounter > 0 && (randomId.equals(i) || !isThreeYearsBackConditionPass(Arrays.asList(year - 3, year - 2, year - 1), i, randomId))) {
                randomId = SecretSantaUtil.pickRandomId(receivers);
                triesCounter--;
            }

            secretSanta.setReceiverId(randomId);
            receivers = SecretSantaUtil.removeFromArray(receivers, randomId);
            secretSantas.add(secretSanta);
        }

        //save all using a hibernate batch
        secretSantaService.addAll(secretSantas);
    }

    private boolean isThreeYearsBackConditionPass(List<Integer> years, int giverId, int receiverId) {
        List<SecretSanta> secretSantas = secretSantaService.findByYearAndGiverId(years, giverId);
        for (SecretSanta secretSanta : secretSantas) {
            if (secretSanta.getReceiverId() == receiverId) return false;
        }
        return true;
    }
}
