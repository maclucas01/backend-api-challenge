package com.home.santa.service;

import com.home.santa.entity.SecretSanta;

import java.util.List;

public interface SecretSantaService {

    List<SecretSanta> findAll();

    List<SecretSanta> findByYear(int year);

    List<SecretSanta> findByYearAndGiverId(List<Integer> years, Integer giverId);

    void addAll(List<SecretSanta> secretSantas);
}
