package com.home.santa.service;

import com.home.santa.dao.SecretSantaDao;
import com.home.santa.entity.SecretSanta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SecretSantaServiceImpl implements SecretSantaService {

    SecretSantaDao secretSantaDao;

    @Autowired
    public void setEmployeeDao(SecretSantaDao secretSantaDao) {
        this.secretSantaDao = secretSantaDao;
    }

    @Override
    @Transactional
    public List<SecretSanta> findAll() {
        return secretSantaDao.findAll();
    }

    @Override
    @Transactional
    public List<SecretSanta> findByYear(int year) {
        return secretSantaDao.findByYear(year);
    }

    @Override
    @Transactional
    public void addAll(List<SecretSanta> secretSantas) {
        secretSantaDao.addAll(secretSantas);
    }

    @Override
    @Transactional
    public List<SecretSanta> findByYearAndGiverId(List<Integer> years, Integer giverId) {
        return secretSantaDao.findByYearAndGiverId(years, giverId);
    }

}
